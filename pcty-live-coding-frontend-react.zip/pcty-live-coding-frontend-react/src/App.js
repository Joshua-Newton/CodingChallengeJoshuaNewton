import EmployeeListingNew from './EmployeeListingNew'

const App = () => {
  return (
    <div className="container-fluid">
      <div className="row">
        <h2>Paylocity Benefits Calculator</h2>
      </div>
      <div className="row">
        <EmployeeListingNew></EmployeeListingNew>
      </div>
    </div>
  );
};

export default App;