// NOTE: This has to match the port that the api is running on. Run the API through visual studio. You should get a swagger api page.
export const baseUrl = 'https://localhost:7124';

//ref: https://stackoverflow.com/a/55556258/725957
export const currencyFormat = (num) => {
    return '$' + num.toFixed(2).replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
};

export const dateFormat = (dateString) => {
    const regex = /^(\d{4})-(\d{2})-(\d{2})T.*/;
    return dateString.replace(regex, "$2/$3/$1");
};