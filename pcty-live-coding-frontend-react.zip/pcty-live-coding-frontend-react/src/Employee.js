import { currencyFormat, dateFormat, baseUrl } from "./Constants";
import React from 'react';

const Employee = (props) => {
    const firstName = props.firstName || '';
    const lastName = props.lastName || '';
    const salary = props.salary || 0;

    const DeleteEmployee = async (id) => {
        const result = await fetch(`${baseUrl}/api/v1/Employees/${id}`, {
            method: 'DELETE',
            headers: {
                'Content-Type' : 'application/json'
            },
            type: 'json'
        })

        props.getEmployees();
    }

    const EditEmployee = async (id) => {
        props.setEmployee(id);
        HidePaycheckMenu();
        ShowEditMenu();
    }

    const ViewPaycheck = async(id) => {
        props.setEmployee(id);
        HideEditMenu();
        ShowPaycheckMenu();
    }

    async function HideEditMenu()
    {
        const element = props.editMenu.current;
        if(element){
            element.style.display = 'none';
        }
    }

    async function ShowEditMenu()
    {
        const element = props.editMenu.current;
        if(element){
            element.style.display = 'block';
        }
    }

    async function HidePaycheckMenu()
    {
        const element = props.paycheckMenu.current;
        if(element){
            element.style.display = 'none';
        }
    }

    async function ShowPaycheckMenu()
    {
        const element = props.paycheckMenu.current;
        if(element){
            element.style.display = 'block';
        }
    }

    

    return (
        <tr>
            <th scope="row">{props.id}</th>
            <td>{lastName}</td>
            <td>{firstName}</td>
            <td>{dateFormat(props.dateOfBirth)}</td>
            <td>{currencyFormat(salary)}</td>
            <td>{props.dependents?.length || 0}</td>
            <td>
                <button onClick={() => {EditEmployee(props.id)}} type="button" class="btn btn-primary">
                    <span>Edit</span>
                </button>
                <button className={"mx-1 btn btn-secondary"} onClick={() => DeleteEmployee(props.id)}>Delete</button>
                <button className={"btn btn-secondary"} onClick={() => ViewPaycheck(props.id)}>View Deductions and</button>
            </td>
        </tr>
    );
};

export default Employee;