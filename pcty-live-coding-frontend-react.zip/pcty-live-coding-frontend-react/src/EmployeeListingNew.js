import React, { useState, useEffect, useRef } from 'react';
import Employee from './Employee';
import { baseUrl, currencyFormat } from './Constants';



const EmployeeListingNew = () => {
    const payPeriods = 26;
    const monthlyDeduction = 1000/12;
    const perDependentMonthlyDeduction = 600/12;
    const [payCheckSalary, setPayCheckSalary] = useState(Number);
    const [basePay, setBasePay] = useState(Number);
    const [standardDeduction, setStandardDeduction] = useState(Number);
    const [dependentDeduction, setDependentDeduction] = useState(Number);
    const [totalDeduction, setTotalDeductions] = useState(Number);
    const [finalPayCheckValue, setFinalPayCheckValue] = useState(Number);

    // React hooks
    const [employees, setEmployees] = useState([]);
    const [currentEmployee, setCurrentEmployee] = useState([]);
    const [error, setError] = useState(null);
    const [newEmployee, setNewEmployee] = useState('');

    // Fields for Employee values.
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [dateOfBirth, setDateOfBirth] = useState('');
    
    // Refs for loading in existing values
    const lastNameRef = React.useRef("");
    const firstNameRef = React.useRef(null);
    const dateOfBirthRef = React.useRef(null);
    const editRef = React.useRef(null);
    const paycheckRef = React.useRef(null);

    const payCheckSalaryRef = React.useRef(null);
    const basePayRef = React.useRef(null);
    const monthlyDeductionRef = React.useRef(null);
    const dependentDeductionRef = React.useRef(null);
    const totalDeductionRef = React.useRef(null);
    const finalPayCheckValueRef = React.useRef(null);
    
    // Calculate paycheck variables
    async function setPayVariables(){
        let _payCheckSalary = (Number(currentEmployee == null ? 0 : currentEmployee.salary))
        setPayCheckSalary(_payCheckSalary)
        // Base Pay
        let _basePay = (Number(currentEmployee == null ? 0 : currentEmployee.salary)/payPeriods)
        setBasePay(_basePay);
        // Standard Deduction
        let _standardDeduction = monthlyDeduction;
        // NOTE: requirements did not specify first or last name incurring the discount. So I'll assume that either or will give the discount.
        if(firstNameRef.current.value.charAt(0).toLowerCase() == 'a' || lastNameRef.current.value.charAt(0).toLowerCase() == 'a'){
            // If first name starts with an "A" then give a 10% discount
            _standardDeduction *= 0.9;
        }
        setStandardDeduction(_standardDeduction);

        // Dependent Deduction
        let _dependentDeduction = 0;
        if(currentEmployee != undefined && currentEmployee.dependents != undefined){
            currentEmployee.dependents.map((dependent, index) => {
                // NOTE: requirements did not specify first or last name incurring the discount. So I'll assume that either or will give the discount.
                if(dependent.firstName.charAt(0).toLowerCase() === 'a' || dependent.lastName.charAt(0).toLowerCase() === 'a'){
                    _dependentDeduction += (perDependentMonthlyDeduction * 0.9);
                }
                else{
                    _dependentDeduction += perDependentMonthlyDeduction;
                }
            });
        }
        setDependentDeduction(_dependentDeduction);
        
        // Final Paycheck value
        let totalDeduction = _standardDeduction + _dependentDeduction;
        let result = _basePay - totalDeduction;
        setTotalDeductions(Number(totalDeduction));
        setFinalPayCheckValue(Number(result));
    }

    // This reaches out to the API to receive the existing employees
    const getEmployees = async () => {
        // fetch from api
        const raw = await fetch(`${baseUrl}/api/v1/Employees`, {
            method: 'GET',
            headers: {
                'Content-Type' : 'application/json'
            }
        });
        // receive response as json
        const response = await raw.json();
        if (response.success) {
            // if successful, set the data to the employees variable
            setEmployees(response.data);
            setError(null);
        }
        else {
            // if not succesful, set employees variable to empty. No rows will render.
            setEmployees([]);
            setError(response.error);
        }
    };

    // This function reaches out to the api and gets an employee with the given ID.
    // If the ID doesn't exist, then set variable to empty or null and prepare to add a new employee.
    async function setEmployee(employeeId){
        //console.log("setEmploye id: " + employeeId);
        // API call to get a specific employee
        const rawEmployee = await fetch(`${baseUrl}/api/v1/Employees/${employeeId}`, {
            method: 'GET',
            headers: {
                'Content-Type' : 'application/json'
            }
        });
        // Get JSON from response
        const responseEmployee = await rawEmployee.json();

        if(responseEmployee.success){
            // If successful then set variables according to the data returned.
            setNewEmployee(false);
            setCurrentEmployee(responseEmployee.data);
            setDependentFields(responseEmployee.data.dependents);
            setFirstName(responseEmployee.data.firstName);
            setLastName(responseEmployee.data.lastName);
            setDateOfBirth(responseEmployee.data.dateOfBirth);
            lastNameRef.current.value = responseEmployee.data.lastName;
            firstNameRef.current.value = responseEmployee.data.firstName;
            dateOfBirthRef.current.value = responseEmployee.data.dateOfBirth.split('T')[0];
        }
        else {
            // If not successful then set variable to prepare a new employee
            setNewEmployee(true);
            setCurrentEmployee(null);
            setDependentFields(null);
            setFirstName(null);
            setLastName(null);
            setDateOfBirth(null);
            lastNameRef.current.value = "";
            firstNameRef.current.value = "";
            dateOfBirthRef.current.value = null;
        }
    }

    const hideEditMenu = () => {
        const element = editRef.current;
        element.style.display = 'none';
    }

    const [dependentFields, setDependentFields] = useState([
        {id: '', lastName: '', firstName: '', dateOfBirth: '', relationship: ''}
    ])

    const possibleRelationships = ["none", "spouse", "domesticPartner", "child"]

    // Function to remove a dependent section in the employee edit menu
    const removeDependent = (index) => {
        let data = [...dependentFields];
        data.splice(index, 1);
        setDependentFields(data);
    }

    function DetermineRelationship(relationship) {
        return possibleRelationships[relationship];
    }

    // This adds another dependent field to the menu
    const addFields = () => {
        let newField = {id: '0', lastName: '', firstName: '', dateOfBirth: '', relationship: ''}
        if(dependentFields){
            setDependentFields([...dependentFields, newField]);
        }
        else {
            setDependentFields([newField]);
        }
    }

    const addEmployee = async () => {
        setEmployee(0);
        editRef.current.style.display = 'block';
        paycheckRef.current.style.display = 'none';
    }


    // Save the employee you're editing/creating
    const SubmitEmployee = async () => {
        const employeeData = {
            FirstName: firstName,
            LastName: lastName,
            salary: 52000,
            DateOfBirth: dateOfBirth,
            Dependents: dependentFields
        }
        
        // If this is a new employee, call POST
        if(newEmployee) {
            const result = await fetch(`${baseUrl}/api/v1/Employees/`, {
                method: 'POST',
                headers: {
                    'Content-Type' : 'application/json'
                },
                body: JSON.stringify(employeeData),
                type: 'json'
            })
        }
        // If this is an existing employee being edited, call PUT
        else {
            const resultEmployeePut = await fetch(`${baseUrl}/api/v1/Employees/UpdateDependents/${currentEmployee.id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type' : 'application/json'
                },
                body: JSON.stringify(employeeData),
                type: 'json'
            })
        }

        getEmployees();
    }

    // Handler for when a dependent field changes
    const handleDependentFormChange = (index, event) => {
        let data = [...dependentFields];
        if(event.target.name == "relationship"){
            switch(event.target.value){
                case "spouse":
                    data[index][event.target.name] = 1;
                    break;
                case "domesticPartner":
                    data[index][event.target.name] = 2;
                    break;
                case "child":
                    data[index][event.target.name] = 3;
                    break;
                default:
                    data[index][event.target.name] = 0;
                    break;
            }
        }
        else {
            data[index][event.target.name] = event.target.value;
        }
        setDependentFields(data);
    }

    // change handlers
    const handleFirstNameChange = event => {
        setFirstName(event.target.value);
    }
    const handleLastNameChange = event => {
        setLastName(event.target.value);
    }
    const handleDateOfBirthChange = event => {
        setDateOfBirth(event.target.value);
    }



    useEffect(() => {
        basePayRef.current.innerHTML = currencyFormat(basePay);
    }, [basePay])

    useEffect(() => {
        payCheckSalaryRef.current.innerHTML = currencyFormat(payCheckSalary);
    }, [payCheckSalary]);
    
    useEffect(() => {
        dependentDeductionRef.current.innerHTML = currencyFormat(dependentDeduction)
    }, [dependentDeduction]);
    
    useEffect(() => {
        finalPayCheckValueRef.current.innerHTML = currencyFormat(finalPayCheckValue);
    }, [finalPayCheckValue]);
    
    
    useEffect(() => {
        totalDeductionRef.current.innerHTML = currencyFormat(totalDeduction);
    }, [totalDeduction]);
    

    // This ensures that the employees variable is always set at render time, and will make sure the listings stay up to date
    useEffect(() => {  
        getEmployees();
        const employeeDetailsElement = editRef.current;
        employeeDetailsElement.style.display = 'none';
        const paycheckDetailsElement = paycheckRef.current;
        paycheckDetailsElement.style.display = 'none';
    }, []);

    
    useEffect(() => {
        //console.log("Current Employee update: " + currentEmployee)
        setPayVariables()
    }, [currentEmployee])

    return (
        <div>
            <div className="employee-listing">
                <table className="table caption-top">
                    <caption>Employees</caption>
                    <thead className="table-dark">
                        <tr>
                            <th scope="col">Id</th>
                            <th scope="col">LastName</th>
                            <th scope="col">FirstName</th>
                            <th scope="col">DOB</th>
                            <th scope="col">Salary</th>
                            <th scope="col">Dependents</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {employees.map(({id, firstName, lastName, dateOfBirth, salary, dependents}) => (
                            <Employee
                                key={id}
                                id={id}
                                firstName={firstName}
                                lastName={lastName}
                                dateOfBirth={dateOfBirth}
                                salary={salary}
                                dependents={dependents}
                                currentEmployee={currentEmployee}
                                setEmployee={setEmployee}
                                getEmployees={getEmployees}
                                editMenu={editRef}
                                paycheckMenu={paycheckRef}
                            />
                        ))}
                    </tbody>
                </table>
            </div>

            <button onClick={() => addEmployee(0)} type="button" className="btn btn-primary">Add Employee</button>
            
            <div ref={editRef} id="edit-menu">
                <div className="row">
                    <div className="col">
                        <h4>Employee Details</h4>
                    </div>
                </div>
                <div className="row">
                    <div className="col-6">
                        <label>LastName</label>
                    </div>
                    <div className="col-6">
                        <input id="idLastName" ref={lastNameRef} type={"text"} onChange={handleLastNameChange}></input>
                    </div>
                </div>
                <div className="row">
                    <div className="col-6">
                        <label>FirstName</label>
                    </div>
                    <div className="col-6">
                        <input id="idFirstName" ref={firstNameRef} type={"text"} onChange={handleFirstNameChange}></input>
                    </div>
                </div>
                <div className="row">
                    <div className="col-6">
                        <label>DOB</label>
                    </div>
                    <div className="col-6">
                        <input id="idDOB" ref={dateOfBirthRef} type={"date"} onChange={handleDateOfBirthChange}></input>
                    </div>
                </div>
                <form>
                    {dependentFields == null ? null : dependentFields.map((input, index) => {
                        return (
                            <div key={index} className="DependentDetails">
                                <div className="row">
                                    <div className="col">
                                        <h4>Dependent</h4>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className='col'>
                                        <button type='button' className='btn btn-secondary' onClick={() => removeDependent(index)}>Remove Dependent</button>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-6">
                                        <label>First Name</label>
                                    </div>
                                    <div className="col-6">
                                        <input 
                                            name="firstName"
                                            value={input.firstName} 
                                            type={"text"}
                                            onChange={event => handleDependentFormChange(index, event)}>
                                        </input>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-6">
                                        <label>Last Name</label>
                                    </div>
                                    <div className="col-6">
                                        <input 
                                            name="lastName"
                                            value={input.lastName}
                                            type={"text"}
                                            onChange={event => handleDependentFormChange(index, event)}>
                                            </input>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-6">
                                        <label>DateOfBirth</label>
                                    </div>
                                    <div className="col-6">
                                        <input 
                                            name="dateOfBirth"
                                            value={input.dateOfBirth.split("T")[0]}
                                            type={"date"}
                                            onChange={event => handleDependentFormChange(index, event)}>
                                        </input>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-6">
                                        <label>Relationship</label>
                                    </div>
                                    <div className="col-6">
                                        <select name="relationship" value={DetermineRelationship(input.relationship)} onChange={event => handleDependentFormChange(index, event)}>
                                            <option value="none">None</option>
                                            <option value="spouse">Spouse</option>
                                            <option value="domesticPartner">Domestic Partner</option>
                                            <option value="child">Child</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        )
                    })}
                </form>
                <div className="row">                    
                    <button type="button" className="col-3 btn btn-secondary float-right" onClick={hideEditMenu}>Close</button>
                    <button type="button" className="col-3 btn btn-secondary float-right" onClick={addFields}>Add Dependent</button>
                    <button type="button" className="col-3 btn btn-primary float-right" onClick={SubmitEmployee}>Save changes</button>
                </div>
            </div>

            <div ref={paycheckRef}>
                <div className='row'>
                    <div className='col-6'>
                        <label>Name: </label>
                    </div>
                    <div className='col-6'>
                        <span>{lastName} , {firstName}</span>
                    </div>
                </div>
                <div className='row'>
                    <div className='col-6'>
                        <label>Salary: </label>
                    </div>
                    <div className="col-6">
                        <span id="idPayCheckSalary" ref={payCheckSalaryRef}></span>
                    </div>
                </div>
                <div className='row'>
                    <div className='col-6'>
                        <label>Base Pay Per Paycheck: </label>
                    </div>
                    <div className="col-6">
                        <span ref={basePayRef}></span>
                    </div>
                </div>
                <div className='row'>
                    <div className='col-6'>
                        <label>Standard Benefit Deduction: </label>
                    </div>
                    <div className="col-6">
                        <span ref={monthlyDeductionRef}>{currencyFormat(standardDeduction)}</span>
                    </div>
                </div>
                <div className='row'>
                    <div className='col-6'>
                        <label>Dependent Deduction: </label>
                    </div>
                    <div className="col-6">
                        <span ref={dependentDeductionRef}></span>
                    </div>
                </div>
                <div className='row'>
                    <div className='col-6'>
                        <label>Total Deduction Per Pay Period: </label>
                    </div>
                    <div className="col-6">
                        <span ref={totalDeductionRef}></span>
                    </div>
                </div>
                <div className='row'>
                    <div className='col-6'>
                        <label>Paycheck Per Pay Period: </label>
                    </div>
                    <div className="col-6">
                        <span ref={finalPayCheckValueRef}></span>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default EmployeeListingNew;