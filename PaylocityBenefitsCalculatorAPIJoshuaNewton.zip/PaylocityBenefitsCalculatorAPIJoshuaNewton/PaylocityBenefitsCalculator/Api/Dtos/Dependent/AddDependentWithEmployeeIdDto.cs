﻿namespace Api.Dtos.Dependent
{
    public class AddDependentWithEmployeeIdDto : AddDependentDto
    {
        public int EmployeeId { get; set; }
    }
}
